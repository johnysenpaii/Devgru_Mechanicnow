<footer class="bg-dark">
<div class="footer-header">
    <div class="footer-logo"><img src="img/footerlogo.png" alt=""></div>
    <h3 class="mechanicnowtitle">Mechanic Now</h3>
</div>
<div class="credits">
    <p>© 2021 Mechanic Now.</p>
</div>
</footer>